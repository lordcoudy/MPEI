﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace smol_PROJECT
{
    public partial class SettingsForm : Form
    {
        public void TemperatureCheck(double temperature, double density, ref int state)
        {
            if (temperature == 0 || density == 0)
            {
                state = 8;
            }
            else
            {
                if (temperature < 1 & density < 10)
                {
                    state = 0;
                }
                else if (temperature < 10 & density <= 10)
                {
                    state = 1;
                }
                else if (temperature < 1.5 * 100 & density < 5 * 10)
                {
                    state = 2;
                }
                else if (temperature < 1.5 * 1000 & density < 10000)
                {
                    state = 3;
                }
                else if (temperature < 2.7 * 1000 & density >= 1)
                {
                    state = 4;
                }
                else if (temperature < 3.5 * 1000 & density >= 1)
                {
                    state = 5;
                }
                else if (temperature < 100000 & density < 10000)
                {
                    state = 6;
                }
                else
                {
                    state = 7;
                }
            }
        }

        public SettingsForm()
        {
            InitializeComponent();
            label11.Text = "0";
            label12.Text = "0";
        }

        
        private Bitmap MyImage ;
        public void ShowMyImage(Bitmap fileToDisplay, int xSize, int ySize)
        {
            if (MyImage != null)
            {
                MyImage.Dispose();
            }
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage ;
            MyImage = fileToDisplay;
            pictureBox1.ClientSize = new Size(xSize, ySize);
            pictureBox1.Image = (Image) MyImage ;
        }
        
        private void Simulate()
        {
            button2.Visible = false;
            Double.TryParse(label11.Text, out double result_temp);
            Double.TryParse(label12.Text, out double result_dens);
            int star_state = 0;
            TemperatureCheck(result_temp, result_dens, ref star_state);
            if (star_state == 8)
            {
                label13.Text = "Звезды не существует";
            }
            else
            {
                progressBar1.Value = (star_state + 1) * 10;
                switch (star_state)
                {
                    case 0:
                    {
                        
                        EarlyProtoStar earlyProtoStar = new EarlyProtoStar(result_temp, result_dens);
                        label13.Text = earlyProtoStar.GetStats() +"\nТемпература: " + result_temp + "\nПлотность: " + result_dens;
                        label14.Text = "Синтез: " + earlyProtoStar.GetElements();
                        ShowMyImage(
                            Properties.Resources.earlyprotostar1,
                            356, 242);
                        break;
                    }
                    case 1:
                    {
                        ProtoStar protoStar = new ProtoStar(result_temp, result_dens);
                        label13.Text = protoStar.GetStats() +"\nТемпература: " + result_temp + "\nПлотность: " + result_dens;
                        label14.Text = "Синтез: " + protoStar.GetElements();
                        ShowMyImage(
                            Properties.Resources.Protostar,
                            356, 242);
                        break;
                    }
                    case 2:
                    {
                        AStar aStar = new AStar(result_temp, result_dens);
                        label13.Text = aStar.GetStats() +"\nТемпература: " + result_temp + "\nПлотность: " + result_dens;
                        label14.Text = "Синтез: " + aStar.GetElements();
                        ShowMyImage(
                            Properties.Resources.AStar,
                            356, 242);
                        break;
                    }
                    case 3:
                    {
                        BStar bStar = new BStar(result_temp, result_dens);
                        label13.Text = bStar.GetStats() +"\nТемпература: " + result_temp + "\nПлотность: " + result_dens;
                        label14.Text = "Синтез: " + bStar.GetElements();
                        ShowMyImage(
                            Properties.Resources.BStar,
                            356, 242);
                        break;
                    }
                    case 4:
                    {
                        FStar fStar = new FStar(result_temp, result_dens);
                        label13.Text = fStar.GetStats() +"\nТемпература: " + result_temp + "\nПлотность: " + result_dens;
                        label14.Text = "Синтез: " + fStar.GetElements();
                        ShowMyImage(
                            Properties.Resources.FStar,
                            356, 242);
                        break;
                    }
                    case 5:
                    {
                        GStar gStar = new GStar(result_temp, result_dens);
                        label13.Text = gStar.GetStats() +"\nТемпература: " + result_temp + "\nПлотность: " + result_dens;
                        label14.Text = "Синтез: " + gStar.GetElements();
                        ShowMyImage(
                            Properties.Resources.GStar,
                            356, 242);
                        break;
                    }
                    case 6:
                    {
                        KStar kStar = new KStar(result_temp, result_dens);
                        label13.Text = kStar.GetStats() +"\nТемпература: " + result_temp + "\nПлотность: " + result_dens;
                        label14.Text = "Синтез: " + kStar.GetElements();
                        ShowMyImage(
                            Properties.Resources.KStar,
                            356, 242);
                        break;
                    }
                    case 7:
                    {
                        NeutronStar neutronStar = new NeutronStar(result_temp, result_dens);
                        label13.Text = neutronStar.GetStats() +"\nТемпература: " + result_temp + "\nПлотность: " + result_dens;
                        label14.Text = "Синтез: " + neutronStar.GetElements();
                        ShowMyImage(
                            Properties.Resources.NeutronStar,
                            356, 242);
                        button2.Visible = true;
                        break;
                    }
                }
            }
        }
        
        private void button1_Click(object sender, EventArgs e)
            {
                double temp_tmp = 0;
                double dens_tmp = 0;
                Generate_Star(ref temp_tmp, ref dens_tmp);
                label11.Text = temp_tmp.ToString();
                label12.Text = dens_tmp.ToString();
                Simulate();
            }
        private void button2_Click(object sender, EventArgs e)
        {
            Double.TryParse(label11.Text, out double temp);
            Double.TryParse(label12.Text, out double dens);
            NeutronStar neutronStar = new NeutronStar(temp, dens);
            BlackHole blackHole = neutronStar.TransformIntoBlackHole();
            ShowMyImage(
                Properties.Resources.BlackStar,
                356, 242);
            label11.Text = blackHole.GetTemp();
            label12.Text = blackHole.GetDens();
            label13.Text = blackHole.GetStats() +"\nТемпература: " + blackHole.GetTemp() + "\nПлотность: " + blackHole.GetDens();
            label14.Text = "Синтез: " + blackHole.GetElements();
            button2.Visible = false;
        }
        
        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            switch (trackBar1.Value)
            {
                case 1:
                {
                    label11.Text = "0.1";
                    label12.Text = "1";
                    Simulate();
                    break;
                }
                case 2:
                {
                    label11.Text = "1";
                    label12.Text = "10";
                    Simulate();
                    break;
                }
                case 3:
                {
                    label11.Text = "10";
                    label12.Text = "10";
                    Simulate();
                    break;
                }
                case 4:
                {
                    label11.Text = "150";
                    label12.Text = "50";
                    Simulate();
                    break;
                }
                case 5:
                {
                    label11.Text = "1500";
                    label12.Text = "10000";
                    Simulate();
                    break;
                }
                case 6:
                {
                    label11.Text = "2700";
                    label12.Text = "1000";
                    Simulate();
                    break;
                }
                case 7:
                {
                    label11.Text = "3500";
                    label12.Text = "1";
                    Simulate();
                    break;
                }
                case 8:
                {
                    label11.Text = "100000";
                    label12.Text = "10000";
                    Simulate();
                    break;
                }
            }
        }
        private void trackBar2_Scroll(object sender, EventArgs e)
        {
            switch (trackBar2.Value)
            {
                case 0:
                {
                    label11.Text = "0.1";
                    Simulate();
                    break;
                }
                case 1:
                {
                    label11.Text = "0.5";
                    Simulate();
                    break;
                }
                case 2:
                {
                    label11.Text = "1";
                    Simulate();
                    break;
                }
                case 3:
                {
                    label11.Text = "5";
                    Simulate();
                    break;
                }
                case 4:
                {
                    label11.Text = "10"; 
                    Simulate();
                    break;
                }
                case 5:
                {
                    label11.Text = "50";
                    Simulate();
                    break;
                }
                case 6:
                {
                    label11.Text = "100";
                    Simulate();
                    break;
                }
                case 7:
                {
                    label11.Text = "150";
                    Simulate();
                    break;
                }
                case 8:
                {
                    label11.Text = "200";
                    Simulate();
                    break;
                }
                case 9:
                {
                    label11.Text = "250";
                    Simulate();
                    break;
                }
                case 10:
                {
                    label11.Text = "300";
                    Simulate();
                    break;
                }
                case 11:
                {
                    label11.Text = "350";
                    Simulate();
                    break;
                }
                case 12:
                {
                    label11.Text = "400";
                    Simulate();
                    break;
                }
                case 13:
                {
                    label11.Text = "450";
                    Simulate();
                    break;
                }
                case 14:
                {
                    label11.Text = "500";
                    Simulate();
                    break;
                }
                case 15:
                {
                    label11.Text = "1000";
                    Simulate();
                    break;
                }
                case 16:
                {
                    label11.Text = "1500";
                    Simulate();
                    break;
                }
                case 17:
                {
                    label11.Text = "2000";
                    Simulate();
                    break;
                }
                case 18:
                {
                    label11.Text = "2500";
                    Simulate();
                    break;
                }
                case 19:
                {
                    label11.Text = "3000";
                    Simulate();
                    break;
                }
                case 20:
                {
                    label11.Text = "3500";
                    Simulate();
                    break;
                }
                case 21:
                {
                    label11.Text = "4000";
                    Simulate();
                    break;
                }
                case 22:
                {
                    label11.Text = "4500";
                    Simulate();
                    break;
                }
                case 23:
                {
                    label11.Text = "5000";
                    Simulate();
                    break;
                }
                case 24:
                {
                    label11.Text = "10000";
                    Simulate();
                    break;
                }
                case 25:
                {
                    label11.Text = "20000";
                    Simulate();
                    break;
                }
                case 26:
                {
                    label11.Text = "30000";
                    Simulate();
                    break;
                }
                case 27:
                {
                    label11.Text = "40000";
                    Simulate();
                    break;
                }
                case 28:
                {
                    label11.Text = "50000";
                    Simulate();
                    break;
                }
                case 29:
                {
                    label11.Text = "100000";
                    Simulate();
                    break;
                }
            }
        }
        private void trackBar3_Scroll(object sender, EventArgs e)
        {
            switch (trackBar3.Value)
            {
                case 0:
                {
                    label12.Text = "0.1";
                    Simulate();
                    break;
                }
                case 1:
                {
                    label12.Text = "0.5";
                    Simulate();
                    break;
                }
                case 2:
                {
                    label12.Text = "1";
                    Simulate();
                    break;
                }
                case 3:
                {
                    label12.Text = "5";
                    Simulate();
                    break;
                }
                case 4:
                {
                    label12.Text = "10";
                    Simulate();
                    break;
                }
                case 5:
                {
                    label12.Text = "50";
                    Simulate();
                    break;
                }
                case 6:
                {
                    label12.Text = "100";
                    Simulate();
                    break;
                }
                case 7:
                {
                    label12.Text = "150";
                    Simulate();
                    break;
                }
                case 8:
                {
                    label12.Text = "200";
                    Simulate();
                    break;
                }
                case 9:
                {
                    label12.Text = "250";
                    Simulate();
                    break;
                }
                case 10:
                {
                    label12.Text = "300";
                    Simulate();
                    break;
                }
                case 11:
                {
                    label12.Text = "350";
                    Simulate();
                    break;
                }
                case 12:
                {
                    label12.Text = "400";
                    Simulate();
                    break;
                }
                case 13:
                {
                    label12.Text = "450";
                    Simulate();
                    break;
                }
                case 14:
                {
                    label12.Text = "500";
                    Simulate();
                    break;
                }
                case 15:
                {
                    label12.Text = "1000";
                    Simulate();
                    break;
                }
                case 16:
                {
                    label12.Text = "1500";
                    Simulate();
                    break;
                }
                case 17:
                {
                    label12.Text = "2000";
                    Simulate();
                    break;
                }
                case 18:
                {
                    label12.Text = "2500";
                    Simulate();
                    break;
                }
                case 19:
                {
                    label12.Text = "3000";
                    Simulate();
                    break;
                }
                case 20:
                {
                    label12.Text = "3500";
                    Simulate();
                    break;
                }
                case 21:
                {
                    label12.Text = "4000";
                    Simulate();
                    break;
                }
                case 22:
                {
                    label12.Text = "4500";
                    Simulate();
                    break;
                }
                case 23:
                {
                    label12.Text = "5000";
                    Simulate();
                    break;
                }
                case 24:
                {
                    label12.Text = "5500";
                    Simulate();
                    break;
                }
                case 25:
                {
                    label12.Text = "6000";
                    Simulate();
                    break;
                }
                case 26:
                {
                    label12.Text = "6500";
                    Simulate();
                    break;
                }
                case 27:
                {
                    label12.Text = "7000";
                    Simulate();
                    break;
                }
                case 28:
                {
                    label12.Text = "7500";
                    Simulate();
                    break;
                }
                case 29:
                {
                    label12.Text = "8000";
                    Simulate();
                    break;
                }
                case 30:
                {
                    label12.Text = "8500";
                    Simulate();
                    break;
                }
                case 31:
                {
                    label12.Text = "9000";
                    Simulate();
                    break;
                }
                case 32:
                {
                    label12.Text = "9500";
                    Simulate();
                    break;
                }
                case 33:
                {
                    label12.Text = "10000";
                    Simulate();
                    break;
                }
            }
        }

        private void Generate_Star(ref double temp_gen, ref double dens_gen)
                {
                    Random random_value = new Random();
                    temp_gen = random_value.NextDouble() * 100000;
                    dens_gen = random_value.NextDouble() * 10000;
                    
                }
    }
}