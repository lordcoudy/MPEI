﻿using System;
using System.Diagnostics;
using System.Numerics;
using System.Threading;
using System.Windows.Forms;

namespace smol_PROJECT
{

    interface IFunctions
    {
        public string GetStats();
        public string GetElements();
    }

    abstract class Star : IFunctions
    {

        protected Star(double start_temperature, double start_density)
        {
            temperature = start_temperature;
            density = start_density;
        }

        public string GetStats()
        {
            return state;
        }

        public string GetElements()
        {
            string elements_un = null;
            if (elements != null)
            {
                foreach (string element in elements)
                { 
                    elements_un += element + "  ";
                } 
                elements_un.Remove(elements_un.Length - 2); 
                return elements_un;

            } else
            {
                return "Не синтезирует элементы";
            }
            
        }

        public abstract void Synthesize();

        protected string state;
        protected double temperature;
        protected double density;
        protected string[] elements;
    }

    class EarlyProtoStar : Star
    {
        public EarlyProtoStar(double temperature, double density) : base(temperature, density)
        {
            Synthesize();
            state = "Гравитационное сжатие";
        }

        public override void Synthesize()
        {
            elements = null;
        }
    }

    class ProtoStar : Star
    {
        public ProtoStar(double temperature, double density) : base(temperature, density)
        {
            Synthesize();
            state = "Протозвезда";
        }
        
        public override void Synthesize()
        {
            elements = new[] {"Deuterium"};
        }
    }

    class AStar : Star
    {
        public AStar(double temperature, double density) : base(temperature, density)
        {
            Synthesize();
            state = "Звезда типа А";
        }

        public override void Synthesize()
        {
            elements = new[] {"Hydrogenium"};
        }
    }

    class BStar : Star
    {
        public BStar(double temperature, double density) : base(temperature, density)
        {
            Synthesize();
            state = "Звезда типа В";
        }

        public override void Synthesize()
        {
            elements = new[] {"Helium"};
        }
    }

    class FStar : Star
    {
        public FStar(double temperature, double density) : base(temperature, density)
        {
            Synthesize();
            state = "Звезда типа F";
        }


        public override void Synthesize()
        {
            elements = new[] {"Calcium", "Oxygenium", "Neon"};
        }
    }

    class GStar : Star
    {
        public GStar(double temperature, double density) : base(temperature, density)
        {
            Synthesize();
            state = "Звезда типа G";
        }

        public override void Synthesize()
        {
            elements = new[] {"Magnesium", "Silicium", "Sulfur", "Argon", "Calcium"};
        }
    }

    class KStar : Star
    {
        public KStar(double temperature, double density) : base(temperature, density)
        {
            Synthesize();
            state = "Звезда типа K";
        }

        public override void Synthesize()
        {
            elements = new[] {"Ferrum"};
        }
    }

    class NeutronStar : Star
    {
        public NeutronStar(double temperature, double density) : base(temperature, density)
        {
            Synthesize();
            state = "Нейтронная звезда";
        }

        public BlackHole TransformIntoBlackHole()
        {
            BlackHole blackHole = new BlackHole(temperature, density);
            return blackHole;
        }
        
        public override void Synthesize()
        {
            elements = null;
        }
    }

    interface IHoleLife
    {
        int delay();
        int temperatureV();
        int densityV();
    }

    interface IHoleDeath
    {
        public void Consume();
        public string GetTemp();
        public string GetDens();
    }
    
    class BlackHole : Star, IHoleLife, IHoleDeath
    {
        delegate void Life();
        public BlackHole(double start_temperature, double start_density) : base(start_temperature, start_density)
        {
            try
            {
                state = "Черная дыра";
                Life life = Synthesize;
                life += Consume;
                life();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }

        public int delay()
        {
            Random randomDelay = new Random();
            int tmp_delay = randomDelay.Next(1000, 3000);
            return tmp_delay;
        }

        public int temperatureV()
        {
            Random randomTemp = new Random();
            return randomTemp.Next(1, 5);
        }

        public int densityV()
        {
            Random randomDens = new Random();
            return randomDens.Next(10, 50);
        }

        private void ShowMessage()
        {
            MessageBox.Show("Состояние звезды: " + state + "\nЭлементы: " + GetElements() + "\nТемпература: " + GetTemp() + "\nПлотность " + GetDens());
        }
        public void Consume()
        {
            ShowMessage();
            Thread.Sleep(delay());
            elements = new[] {"Dark matter"};
            temperature = temperatureV();
            density = densityV();
            ShowMessage();
            Thread.Sleep(delay());
            elements = null;
            temperature = 0;
            density = 0;
            state = "Звезда прекратила свое существование";
            ShowMessage();
        }

        public string GetTemp()
        {
            return temperature.ToString();
        }

        public string GetDens()
        {
            return density.ToString();
        }

        public override void Synthesize()
        {
            elements = null;
        }

    }
}