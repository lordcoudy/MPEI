<?php
// отслеживает время последнего посещения страницы с момента ее закрытия (которое хранится в cookie файле).
date_default_timezone_set('Europe/Moscow');

$last = isset($_COOKIE['last']) ? $_COOKIE['last'] : 'никогда';

setcookie('last', date('Y-m-d H:i:s'), time()+3600*24*31, '/');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Check work, Balashov, A-08-19</title>
</head>
<body>
<p>Last visited: <?php echo $last; ?></p>
</body>
</html>
