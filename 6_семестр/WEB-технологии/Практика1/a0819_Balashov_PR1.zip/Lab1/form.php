<?php
    error_reporting (E_ALL ^ E_WARNING);
    $instrument = $_GET['instrument'];
    $color = $_GET['color'];
    $quantity = $_GET['quantity'];
    $notebookSize = $_GET['notebookSize'];
    $line = $_GET['line'];
    $square = $_GET['square'];
    $ruler = $_GET['ruler'];
    $code = $_GET['code'];
    $name = $_GET['name'];
    $address = $_GET['address'];
    $mail = $_GET['mail'];
    $tel = $_GET['tel'];
    $eraser = $_GET['eraser'];
    $stickers = $_GET['stickers'];
    if (!isset($line))
    {

       $line = 'не выбран';
    }
    if (!isset($square))
    {
        $square = 'не выбран';
    }
    if (trim($quantity) == '')
    {
        $quantity = 'не указано';
    }
    if (trim($code) == '')
    {
        $code = 'не введен';
    }
    if (trim($name) == '')
    {
        $name = 'не введено!';
    }
    if (trim($address) == '')
    {
        $address = 'не введен!';
    }
    if (trim($mail) == '')
    {
        $mail = 'не введен!';
    }
    if (trim($tel) == '')
    {
        $tel = 'не введен!';
    }
    if (!isset($eraser))
    {
        $eraser= 'не выбран';
    }
    if (!isset($instrument)) {
        $instrument = 'не выбран';
    }
    if (!isset($ruler)) {
        $ruler = 'не выбран';
    }
    if (!isset($stickers))
    {
        $stickers = 'не выбран';
    }
        echo "<p>Инструмент: $instrument</p><p>Цвет: $color</p><p>$quantity шт.</p><p>Тетрадь: $notebookSize</p><p>1 вариант: $line</p><p>2 вариант: $square</p><p>Линейка: $ruler</p><p>Промокод на скидку: $code</p><p>ФИО: $name</p><p>Адрес: $address</p><p>Mail: $mail</p><p>Телефон: $tel</p><p>Доп. 1: $eraser</p><p>Доп. 2:$stickers</p>";

