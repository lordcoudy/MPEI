#include <stdio.h>
#include <stdlib.h>

#include "bmpfile.h"

#include "../3rdparty/stdint.h"

#pragma pack(push,1)
struct bmpfile_magic {
    unsigned char magic[2];
};
 
struct bmpfile_header {
    uint32_t filesz;
    uint16_t creator1;
    uint16_t creator2;
    uint32_t bmp_offset;
};

struct bmp_dib_v3_header_t{
    uint32_t header_sz;
    uint32_t width;
    uint32_t height;
    uint16_t nplanes;
    uint16_t bitspp;
    uint32_t compress_type;
    uint32_t bmp_bytesz;
    uint32_t hres;
    uint32_t vres;
    uint32_t ncolors;
    uint32_t nimpcolors;
};
#pragma pack(pop)

typedef enum {
    BI_RGB = 0,
    BI_RLE8,
    BI_RLE4,
    BI_BITFIELDS,
    BI_JPEG,
    BI_PNG,
} bmp_compression_method_t;

void Array2Bitmap(const char *path, const unsigned char *data, unsigned w, unsigned h, unsigned bpp){ //24bpp, uncompressed
    FILE *f=fopen(path,"wb");
    if(!f)
        return;
    fwrite("BM",2,1,f); //writing magic signature
    bmpfile_header hdr1;
    hdr1.bmp_offset=2+sizeof(bmp_dib_v3_header_t)+sizeof(bmpfile_header);
    hdr1.creator1=0;
    hdr1.creator2=0;
    hdr1.filesz=2+sizeof(bmpfile_header)+sizeof(bmp_dib_v3_header_t)+(w%4?((w>>2)+1)<<2:w)*h*3;
    fwrite(&hdr1,sizeof(hdr1),1,f);

    unsigned Bpp=bpp/8;
    bmp_dib_v3_header_t hdr2;
    hdr2.header_sz=sizeof(bmp_dib_v3_header_t);
    hdr2.width=w;
    hdr2.height=h;
    hdr2.nplanes=1;
    hdr2.bitspp=bpp;
    hdr2.compress_type=BI_RGB;
    hdr2.bmp_bytesz=(w%4?((w>>2)+1)<<2:w)*h*Bpp;
    hdr2.hres=1000;
    hdr2.vres=1000;
    hdr2.ncolors=0;
    hdr2.nimpcolors=0;
    fwrite(&hdr2,sizeof(hdr2),1,f);

    int padding=0;
    unsigned plen=(w*3)&3?4-((w*3)&3):0;
    const unsigned char *ptr=data;
    unsigned linesize=w*Bpp;
    for(unsigned i=0;i<h;i++){
        fwrite(ptr,linesize,1,f);
        if(plen)
            fwrite(&padding,plen,1,f);
        ptr+=linesize;
    }
    fclose(f);
}

bool Bitmap2Array(const char *path, unsigned char **pdata, unsigned *pw, unsigned *ph, unsigned *pbpp){ //24bpp, uncompressed
    FILE *f=fopen(path,"rb");
    if(!f)
        return false;
    char magic[2]={0};
    fread(magic,2,1,f);
    if(magic[0]!='B'||magic[1]!='M'){ //not a BMP
        fclose(f);
        return false;
    }
    bmpfile_header hdr1;
    fread(&hdr1,sizeof(hdr1),1,f);

    bmp_dib_v3_header_t hdr2;
    fread(&hdr2,sizeof(hdr2),1,f);
    if(hdr2.compress_type!=BI_RGB||(hdr2.bitspp!=8&&hdr2.bitspp!=24)){
        fclose(f);
        return false; //unsupported format
    }

    fseek(f, hdr1.bmp_offset, SEEK_SET); //move to bitmap

    //reading
    //initializing variables
    unsigned h=hdr2.height, w=hdr2.width;
    unsigned Bpp=hdr2.bitspp/8;
    int padding=0;
    unsigned plen=(w*Bpp)&3?4-((w*Bpp)&3):0;
    unsigned linesize=w*Bpp;
    //allocating
    unsigned char *data=(unsigned char *)malloc(w*h*Bpp);
    if(data==NULL){
        fclose(f);
        return false;
    }
    unsigned char *ptr=data;
    //set output data
    *pdata=data;
    *pw=w;
    *ph=h;
    *pbpp=hdr2.bitspp;
    //reading itself
    for(unsigned i=0;i<h;i++){
        fread(ptr,linesize,1,f);
        if(plen)
            fread(&padding,plen,1,f);
        ptr+=linesize;
    }
    fclose(f);
    return true;
}
