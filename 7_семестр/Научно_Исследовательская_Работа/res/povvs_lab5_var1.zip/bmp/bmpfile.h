#ifndef BMP_FILE_H
#define BMP_FILE_H

#ifdef __cplusplus
//extern "C" {
#endif

void Array2Image(const char *path, const unsigned char *data, unsigned w, unsigned h, unsigned bpp);
bool Image2Array(const char *path, unsigned char **pdata, unsigned *pw, unsigned *ph, unsigned *pbpp);

void Array2Bitmap(const char *path, const unsigned char *data, unsigned w, unsigned h, unsigned bpp);
bool Bitmap2Array(const char *path, unsigned char **pdata, unsigned *pw, unsigned *ph, unsigned *pbpp);

bool Array2Targa(const char *path, const unsigned char *data, unsigned w, unsigned h, unsigned bpp);
bool Targa2Array(const char *path, unsigned char **pdata, unsigned *pw, unsigned *ph, unsigned *pbpp);

#ifdef __cplusplus
//}
#endif

#endif
