#include <string.h>
#include "bmpfile.h"

bool DetectFormat(const char *str){
    const char *targa_ext=".tga";
    size_t targa_ext_len=4;
    size_t l=strlen(str);
    if(l<targa_ext_len) return false; //BMP
    if(!strncmp(targa_ext, str+l-targa_ext_len, targa_ext_len)) return true; //TGA
    return false; // BMP
}

void Array2Image(const char *path, const unsigned char *data, unsigned w, unsigned h, unsigned bpp){
    if(DetectFormat(path))
        Array2Targa(path, data, w, h, bpp);
    else
        Array2Bitmap(path, data, w, h, bpp);
}

bool Image2Array(const char *path, unsigned char **pdata, unsigned *pw, unsigned *ph, unsigned *pbpp){
    if(DetectFormat(path))
        return Targa2Array(path, pdata, pw, ph, pbpp);
    else
        return Bitmap2Array(path, pdata, pw, ph, pbpp);
}
