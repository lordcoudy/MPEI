#include <stdlib.h>
#include <stdio.h>
#include <sys/time.h>
#include "bmp/bmpfile.h"

template <class T> T* at(T *data, unsigned w, unsigned h, unsigned Bpp, int x, int y){
    if(x<0) x=0;
    if(x>=(int)w) x=w-1;
    if(y<0) y=0;
    if(y>=(int)h) y=h-1;
    return data+(x+y*w)*Bpp;
}

void Convol(const unsigned char *in, unsigned w, unsigned h, unsigned bpp, unsigned char *out){
    unsigned Bpp=bpp/8;
    const unsigned n=3; //matrix 3x3
    const int d=n/2;
    const int m[n][n]={{-1,-1,-1}, //convolution kernel
                       {-1, 9,-1},
                       {-1,-1,-1}};
    //main loop
    for(int j=0; j<(int)h; ++j){
        for(int i=0; i<(int)w; ++i){
            //compute convolution for each pixel (it's not optimal, but obvious)
            int s[3]={0};
            for(int t=-d; t<=d; ++t){
                for(int k=-d; k<=d; ++k){
                    const unsigned char *ptr=at(in, w, h, Bpp, i+k, j+t);
                    for(unsigned l=0; l<Bpp; ++l)
                        s[l]+=(int)m[t+d][k+d]*(int)ptr[l];
                }
            }
            //copy to output data
            unsigned char *tptr=at(out, w, h, Bpp, i, j);
            for(unsigned l=0; l<Bpp; ++l)
              tptr[l]=s[l]<0?0:(s[l]>255?255:s[l]);
        }
    }
}

int main(int argc, char **argv){
    if(argc!=3)
        return 1;
    unsigned char *data;
    unsigned w=0, h=0, bpp=0;
    if(!Image2Array(argv[1], &data, &w, &h, &bpp))
        return 1;
    //here convolution comes
    unsigned char* data2=(unsigned char *)malloc(w*h*(bpp/8));
    struct timeval ts, te;
    gettimeofday(&ts, NULL);
    Convol(data,w,h,bpp,data2);
    gettimeofday(&te, NULL);
    fprintf(stderr, "Processing via CPU, single-thread: %d ms\n", int((te.tv_sec-ts.tv_sec)*1000+(te.tv_usec-ts.tv_usec)/1000));
    Array2Image(argv[2], data2, w, h, bpp);
    free(data);
    free(data2);
    return 0;
}
